%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex(void);
void yyerror(const char *s);


int lexicalMode = 0;
int temp = 1, label = 1;
char start[10], end[10], body[10], forVar[50];

char *newtemp() {
    char *s = malloc(20);
    sprintf(s, "t%d", temp++);
    return s;
}
%}

%union {
    int num;
    char *str;
}

%token WHILE FOR LT ASSIGN PLUS MINUS MUL DIV INC
%token LPAREN RPAREN LBRACE RBRACE SEMICOLON
%token <num> NUMBER
%token <str> ID

%type <str> expr

%left PLUS MINUS
%left MUL DIV

%%

program:
    WHILE {
        sprintf(start, "L%d", label++);
        sprintf(end, "L%d", label++);
        sprintf(body, "L%d", label++);
        printf("%s:\n", start);
    }
    LPAREN expr LT expr RPAREN {
        printf("if %s < %s goto %s\n", $4, $6, body);
        printf("goto %s\n%s:\n", end, body);
    }
    LBRACE statements RBRACE {
        printf("goto %s\n%s:\n", start, end);
        printf("Statement is syntactically correct.\n");
    }
    |
    FOR LPAREN for_init
    expr LT expr SEMICOLON ID INC RPAREN
    {
        printf("if %s < %s goto %s\n", $4, $6, body);
        printf("goto %s\n", end);
        printf("%s:\n", body);
    }
    LBRACE statements RBRACE
    {
        printf("%s = %s + 1\n", forVar, forVar);
        printf("goto %s\n", start);
        printf("%s:\n", end);
        printf("Statement is syntactically correct.\n");
    }
    ;

for_init:
    ID ASSIGN expr SEMICOLON
    {
        printf("%s = %s\n", $1, $3);
        strcpy(forVar, $1);

        sprintf(start, "L%d", label++);
        sprintf(body, "L%d", label++);
        sprintf(end, "L%d", label++);

        printf("%s:\n", start);
    }
    ;

statements:
    statements statement
    | statement
    ;

statement:
    ID ASSIGN expr SEMICOLON {
        printf("%s = %s\n", $1, $3);
    }
    ;

expr:
    expr PLUS expr {
        $$ = newtemp();
        printf("%s = %s + %s\n", $$, $1, $3);
    }
    | expr MINUS expr {
        $$ = newtemp();
        printf("%s = %s - %s\n", $$, $1, $3);
    }
    | expr MUL expr {
        $$ = newtemp();
        printf("%s = %s * %s\n", $$, $1, $3);
    }
    | expr DIV expr {
        $$ = newtemp();
        printf("%s = %s / %s\n", $$, $1, $3);
    }
    | LPAREN expr RPAREN { $$ = $2; }
    | ID { $$ = $1; }
    | NUMBER {
        $$ = malloc(20);
        sprintf($$, "%d", $1);
    }
    ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Syntax error: %s\n", s);
}

int main(void) {
    printf("Enter the while-loop program:\n");
    return yyparse();
}