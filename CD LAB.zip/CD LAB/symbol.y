
%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex(void);
void yyerror(const char *s);

struct Symbol {
    char name[50];
    int initialized;
};

struct Symbol table[100];
int count = 0;
int errors = 0;

int lookup(char *name) {
    for (int i = 0; i < count; i++) {
        if (strcmp(table[i].name, name) == 0)
            return i;
    }
    return -1;
}

void insert(char *name, int initialized) {
    strcpy(table[count].name, name);
    table[count].initialized = initialized;
    count++;
}

void check_initialized(char *name) {
    int i = lookup(name);
    if (i == -1) {
        printf("Error: '%s' is undeclared\n", name);
        errors++;
    } else if (!table[i].initialized) {
        printf("Error: '%s' is not initialized\n", name);
        errors++;
    }
}

void assign_value(char *name) {
    int i = lookup(name);
    if (i == -1) {
        printf("Error: '%s' is undeclared\n", name);
        errors++;
    } else {
        table[i].initialized = 1;
    }
}
%}

%union {
    int num;
    char *str;
}

%token INT ASSIGN PLUS SEMICOLON
%token <num> NUM
%token <str> ID

%type <num> expression

%%

program:
    statements
    ;

statements:
    statements statement
    | statement
    ;

statement:
    INT ID SEMICOLON
    {
        if (lookup($2) != -1) {
            printf("Error: '%s' is already declared\n", $2);
            errors++;
        } else {
            insert($2, 0);
            printf("Declared: %s\n", $2);
        }
    }
    | INT ID ASSIGN expression SEMICOLON
    {
        if (lookup($2) != -1) {
            printf("Error: '%s' is already declared\n", $2);
            errors++;
        } else {
            insert($2, 1);
            printf("Declared and initialized: %s\n", $2);
        }
    }
    | ID ASSIGN expression SEMICOLON
    {
        assign_value($1);
    }
    ;

expression:
    expression PLUS expression
    {
        $$ = $1 + $3;
    }
    | NUM
    {
        $$ = $1;
    }
    | ID
    {
        int i = lookup($1);
        if (i == -1) {
            printf("Error: '%s' is undeclared\n", $1);
            errors++;
            $$ = 0;
        } else if (!table[i].initialized) {
            printf("Error: '%s' is not initialized\n", $1);
            errors++;
            $$ = 0;
        } else {
            $$ = 0;
        }
    }
    ;

%%

void yyerror(const char *s) {
    printf("Syntax Error: %s\n", s);
}

int main(void) {
    printf("Enter statements (Ctrl+D to finish):\n");
    yyparse();

    printf("\nSymbol Table:\n");
    printf("Name\tInitialized\n");

    for (int i = 0; i < count; i++) {
        printf("%s\t%s\n",
               table[i].name,
               table[i].initialized ? "Yes" : "No");
    }

    if (errors == 0)
        printf("\nCompilation successful!\n");
    else
        printf("\nCompilation failed with %d error(s).\n", errors);

    return 0;
}
