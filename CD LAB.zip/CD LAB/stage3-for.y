%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex(void);
void yyerror(const char *);

extern FILE *yyin;
void yyrestart(FILE *);

int stage = 1;
int parseError = 0;

int tempCount = 0;
int labelCount = 0;

int loopStart, loopEnd;

char *duplicate(const char *s)
{
    char *p = strdup(s);

    if (p == NULL) {
        perror("strdup");
        exit(EXIT_FAILURE);
    }

    return p;
}

char *newtemp(void)
{
    char buf[30];

    sprintf(buf, "t%d", ++tempCount);

    return duplicate(buf);
}

int newlabel(void)
{
    return ++labelCount;
}

void emit(const char *s)
{
    if (stage == 3)
        printf("%s\n", s);
}

void openInput(const char *filename)
{
    if (yyin != NULL && yyin != stdin)
        fclose(yyin);

    yyin = fopen(filename, "r");

    if (yyin == NULL) {
        perror(filename);
        exit(EXIT_FAILURE);
    }

    yyrestart(yyin);
}
%}

%union {
    char *s;
}

%token FOR INT
%token <s> ID NUM

%token ASSIGN PLUS MINUS MUL DIV
%token LT GT LE GE EQ NE INC
%token LPAREN RPAREN LBRACE RBRACE SEMICOLON

%type <s> expression condition for_update

%left PLUS MINUS
%left MUL DIV

%%

program:
    statement_list
    ;

statement_list:
    statement_list statement
    | statement
    ;

statement:
    for_statement
    | assignment SEMICOLON
    | declaration SEMICOLON
    | compound_statement
    ;

for_statement:
    FOR LPAREN for_init SEMICOLON
    {
        loopStart = newlabel();
        loopEnd = newlabel();

        char buf[50];

        sprintf(buf, "L%d:", loopStart);
        emit(buf);
    }
    condition SEMICOLON
    {
        char buf[300];

        sprintf(buf, "ifFalse %s goto L%d",
                $6, loopEnd);

        emit(buf);
    }
    for_update RPAREN statement
    {
        emit($9);

        char buf[50];

        sprintf(buf, "goto L%d", loopStart);
        emit(buf);

        sprintf(buf, "L%d:", loopEnd);
        emit(buf);
    }
    ;

for_init:
    assignment
    | declaration
    ;

for_update:
    ID INC
    {
        char buf[200];

        sprintf(buf, "%s = %s + 1", $1, $1);

        $$ = duplicate(buf);
    }
    ;

assignment:
    ID ASSIGN expression
    {
        char buf[200];

        sprintf(buf, "%s = %s", $1, $3);

        emit(buf);
    }
    ;

declaration:
    INT ID
    {
        /* Declaration without initialization. */
    }
    | INT ID ASSIGN expression
    {
        char buf[200];

        sprintf(buf, "%s = %s", $2, $4);

        emit(buf);
    }
    ;

compound_statement:
    LBRACE statement_list RBRACE
    ;

condition:
    expression LT expression
    {
        char buf[200];

        sprintf(buf, "%s < %s", $1, $3);

        $$ = duplicate(buf);
    }
    | expression GT expression
    {
        char buf[200];

        sprintf(buf, "%s > %s", $1, $3);

        $$ = duplicate(buf);
    }
    | expression LE expression
    {
        char buf[200];

        sprintf(buf, "%s <= %s", $1, $3);

        $$ = duplicate(buf);
    }
    | expression GE expression
    {
        char buf[200];

        sprintf(buf, "%s >= %s", $1, $3);

        $$ = duplicate(buf);
    }
    | expression EQ expression
    {
        char buf[200];

        sprintf(buf, "%s == %s", $1, $3);

        $$ = duplicate(buf);
    }
    | expression NE expression
    {
        char buf[200];

        sprintf(buf, "%s != %s", $1, $3);

        $$ = duplicate(buf);
    }
    ;

expression:
    expression PLUS expression
    {
        $$ = newtemp();

        char buf[200];

        sprintf(buf, "%s = %s + %s", $$, $1, $3);

        emit(buf);
    }
    | expression MINUS expression
    {
        $$ = newtemp();

        char buf[200];

        sprintf(buf, "%s = %s - %s", $$, $1, $3);

        emit(buf);
    }
    | expression MUL expression
    {
        $$ = newtemp();

        char buf[200];

        sprintf(buf, "%s = %s * %s", $$, $1, $3);

        emit(buf);
    }
    | expression DIV expression
    {
        $$ = newtemp();

        char buf[200];

        sprintf(buf, "%s = %s / %s", $$, $1, $3);

        emit(buf);
    }
    | LPAREN expression RPAREN
    {
        $$ = $2;
    }
    | ID
    {
        $$ = $1;
    }
    | NUM
    {
        $$ = $1;
    }
    ;

%%

void yyerror(const char *s)
{
    parseError = 1;

    if (stage == 2)
        fprintf(stderr, "Syntax error: %s\n", s);
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        printf("Usage: %s input_for.c\n", argv[0]);
        return 1;
    }

    /* PART A: LEXICAL ANALYSIS */

    stage = 1;

    printf("\n========== PART A: TOKEN IDENTIFICATION ==========\n");

    openInput(argv[1]);

    while (yylex() != 0)
        ;

    /* PART B: SYNTAX VALIDATION */

    stage = 2;
    parseError = 0;

    printf("\n========== PART B: SYNTAX VALIDATION ==========\n");

    openInput(argv[1]);

    if (yyparse() != 0 || parseError) {
        printf("Syntax is invalid.\n");
        return 1;
    }

    printf("Syntax is valid!\n");

    /* PART C: TAC GENERATION */

    stage = 3;

    tempCount = 0;
    labelCount = 0;
    parseError = 0;

    printf("\n========== PART C: THREE ADDRESS CODE ==========\n");

    openInput(argv[1]);

    if (yyparse() != 0 || parseError) {
        printf("TAC generation failed.\n");
        return 1;
    }

    if (yyin != NULL && yyin != stdin)
        fclose(yyin);

    return 0;
}