
%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex(void);
void yyerror(const char *);

int tempCount = 0;
int labelCount = 0;
int loopStart, loopEnd;

char *newtemp(void) {
    char buf[20];
    sprintf(buf, "t%d", ++tempCount);
    return strdup(buf);
}

int newlabel(void) {
    return ++labelCount;
}
%}

%union {
    char *s;
}

%token WHILE
%token <s> ID NUM
%token ASSIGN PLUS MINUS MUL DIV
%token LT GT LE GE EQ NE
%token LPAREN RPAREN LBRACE RBRACE SEMICOLON

%type <s> expression condition

%left PLUS MINUS
%left MUL DIV

%%

program:
    statement
    ;

statement:
    WHILE LPAREN
    {
        loopStart = newlabel();
        loopEnd = newlabel();
        printf("L%d:\n", loopStart);
    }
    condition RPAREN
    {
        printf("ifFalse %s goto L%d\n", $4, loopEnd);
    }
    compound_statement
    {
        printf("goto L%d\n", loopStart);
        printf("L%d:\n", loopEnd);
    }
    | ID ASSIGN expression SEMICOLON
    {
        printf("%s = %s\n", $1, $3);
    }
    ;

compound_statement:
    LBRACE statement_list RBRACE
    ;

statement_list:
    statement_list statement
    | statement
    ;

condition:
    expression LT expression
    {
        char buf[200];
        sprintf(buf, "%s < %s", $1, $3);
        $$ = strdup(buf);
    }
    | expression GT expression
    {
        char buf[200];
        sprintf(buf, "%s > %s", $1, $3);
        $$ = strdup(buf);
    }
    | expression LE expression
    {
        char buf[200];
        sprintf(buf, "%s <= %s", $1, $3);
        $$ = strdup(buf);
    }
    | expression GE expression
    {
        char buf[200];
        sprintf(buf, "%s >= %s", $1, $3);
        $$ = strdup(buf);
    }
    | expression EQ expression
    {
        char buf[200];
        sprintf(buf, "%s == %s", $1, $3);
        $$ = strdup(buf);
    }
    | expression NE expression
    {
        char buf[200];
        sprintf(buf, "%s != %s", $1, $3);
        $$ = strdup(buf);
    }
    ;

expression:
    expression PLUS expression
    {
        $$ = newtemp();
        printf("%s = %s + %s\n", $$, $1, $3);
    }
    | expression MINUS expression
    {
        $$ = newtemp();
        printf("%s = %s - %s\n", $$, $1, $3);
    }
    | expression MUL expression
    {
        $$ = newtemp();
        printf("%s = %s * %s\n", $$, $1, $3);
    }
    | expression DIV expression
    {
        $$ = newtemp();
        printf("%s = %s / %s\n", $$, $1, $3);
    }
    | LPAREN expression RPAREN
    {
        $$ = $2;
    }
    | ID  { $$ = $1; }
    | NUM { $$ = $1; }
    ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Syntax error: %s\n", s);
}

int main(void) {
    printf("Three-address code:\n");
    yyparse();
    return 0;
}
