
%{
#include <stdio.h>

int yylex(void);
void yyerror(const char *s);
%}

%token WHILE INT ID NUM
%token ASSIGN PLUS MINUS MUL DIV
%token LT GT LE GE EQ NE INC DEC
%token LPAREN RPAREN LBRACE RBRACE SEMICOLON

%left PLUS MINUS
%left MUL DIV

%%

program:
    statement_list
    ;

statement_list:
    statement_list statement
    | statement
    ;

statement:
    while_statement
    | assignment SEMICOLON
    | declaration SEMICOLON
    | compound_statement
    ;

while_statement:
    WHILE LPAREN condition RPAREN statement
    ;

assignment:
    ID ASSIGN expression
    ;

declaration:
    INT ID
    | INT ID ASSIGN expression
    ;

condition:
    expression relational_operator expression
    ;

relational_operator:
    LT | GT | LE | GE | EQ | NE
    ;

compound_statement:
    LBRACE statement_list RBRACE
    ;

expression:
    expression PLUS expression
    | expression MINUS expression
    | expression MUL expression
    | expression DIV expression
    | LPAREN expression RPAREN
    | ID
    | NUM
    ;

%%

void yyerror(const char *s)
{
    fprintf(stderr, "Syntax error: %s\n", s);
}

int main(void)
{
    if (yyparse() == 0)
        printf("Syntax is correct!\n");

    return 0;
}
