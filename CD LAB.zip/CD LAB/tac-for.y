
%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex(void);
void yyerror(const char *);

int tempCount = 0, labelCount = 0;
int loopStart, loopEnd;
char *updateCode;

char *newtemp(void) {
    char buf[20];
    sprintf(buf, "t%d", ++tempCount);
    return strdup(buf);
}

int newlabel(void) {
    return ++labelCount;
}
%}

%union {
    char *s;
}

%token FOR INT
%token <s> ID NUM
%token ASSIGN PLUS MINUS MUL DIV
%token LT GT LE GE EQ NE INC
%token LPAREN RPAREN LBRACE RBRACE SEMICOLON

%type <s> expression condition

%left PLUS MINUS
%left MUL DIV

%%

program:
    statement_list
    ;

statement_list:
    statement_list statement
    | statement
    ;

statement:
    for_statement
    | assignment SEMICOLON
    | declaration SEMICOLON
    | compound_statement
    ;

for_statement:
    FOR LPAREN for_init SEMICOLON
    {
        loopStart = newlabel();
        loopEnd = newlabel();
        printf("L%d:\n", loopStart);
    }
    condition SEMICOLON
    {
        printf("ifFalse %s goto L%d\n", $6, loopEnd);
    }
    for_update RPAREN statement
    {
        printf("%s\n", updateCode);
        printf("goto L%d\n", loopStart);
        printf("L%d:\n", loopEnd);
    }
    ;

for_init:
    assignment
    | declaration
    ;

for_update:
    ID INC
    {
        char buf[100];
        sprintf(buf, "%s = %s + 1", $1, $1);
        updateCode = strdup(buf);
    }
    ;

assignment:
    ID ASSIGN expression
    {
        printf("%s = %s\n", $1, $3);
    }
    ;

declaration:
    INT ID
    | INT ID ASSIGN expression
    {
        printf("%s = %s\n", $2, $4);
    }
    ;

condition:
    expression LT expression
    {
        char buf[200];
        sprintf(buf, "%s < %s", $1, $3);
        $$ = strdup(buf);
    }
    | expression GT expression
    {
        char buf[200];
        sprintf(buf, "%s > %s", $1, $3);
        $$ = strdup(buf);
    }
    | expression LE expression
    {
        char buf[200];
        sprintf(buf, "%s <= %s", $1, $3);
        $$ = strdup(buf);
    }
    | expression GE expression
    {
        char buf[200];
        sprintf(buf, "%s >= %s", $1, $3);
        $$ = strdup(buf);
    }
    | expression EQ expression
    {
        char buf[200];
        sprintf(buf, "%s == %s", $1, $3);
        $$ = strdup(buf);
    }
    | expression NE expression
    {
        char buf[200];
        sprintf(buf, "%s != %s", $1, $3);
        $$ = strdup(buf);
    }
    ;

compound_statement:
    LBRACE statement_list RBRACE
    ;

expression:
    expression PLUS expression
    {
        $$ = newtemp();
        printf("%s = %s + %s\n", $$, $1, $3);
    }
    | expression MINUS expression
    {
        $$ = newtemp();
        printf("%s = %s - %s\n", $$, $1, $3);
    }
    | expression MUL expression
    {
        $$ = newtemp();
        printf("%s = %s * %s\n", $$, $1, $3);
    }
    | expression DIV expression
    {
        $$ = newtemp();
        printf("%s = %s / %s\n", $$, $1, $3);
    }
    | LPAREN expression RPAREN
    {
        $$ = $2;
    }
    | ID  { $$ = $1; }
    | NUM { $$ = $1; }
    ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Syntax error: %s\n", s);
}

int main(void) {
    printf("Three-address code:\n");
    yyparse();
    return 0;
}


/* i = 0
L1:
t1 = i < 5
ifFalse t1 goto L3
t2 = x + i
x = t2
t3 = i + 1
i = t3
goto L1
L3:

int i = 0;
for (i = 0; i < 5; i = i + 1)
{
    x = x + i;
} */